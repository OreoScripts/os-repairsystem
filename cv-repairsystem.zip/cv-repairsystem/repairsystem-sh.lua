Config = {}

Config.Mechanics = {
    { -- Mechanic 1
        coords = vec3(-212.0682, -1324.342, 30.468223),
        showBlip = true,
        blipData = {
            sprite = 72,
            display = 4,
            scale = 0.65,
            colour = 66,
            title = "Bennys",
            minZ = 29.468223, -- for polyzone(whre the drawtext will be)
            maxZ = 31.468223  -- for polyzone(whre the drawtext will be)
    }
    },
}
